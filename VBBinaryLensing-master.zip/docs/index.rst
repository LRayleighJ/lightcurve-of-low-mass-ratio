Documentation
=============

This is the documentation for VBBinaryLensing.
...

.. toctree::
  :maxdepth: 2

  VBBinaryLensing/index.rst

.. note:: The layout of this directory is simply a suggestion.  To follow
          traditional practice, do *not* edit this page, but instead place
          all documentation for the package inside ``VBBinaryLensing/``.
          You can follow this practice or choose your own layout.
