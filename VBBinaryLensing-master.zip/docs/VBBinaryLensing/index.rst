*****************************
VBBinaryLensing Documentation
*****************************

This is the documentation for VBBinaryLensing.

Reference/API
=============

.. automodapi:: VBBinaryLensing
